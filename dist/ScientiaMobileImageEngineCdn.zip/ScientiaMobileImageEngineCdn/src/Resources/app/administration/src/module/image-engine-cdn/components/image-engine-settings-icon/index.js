import template from './image-engine-settings-icon.html.twig';

const { Component } = Shopware;

Component.register('image-engine-settings-icon', {
    template,
});
